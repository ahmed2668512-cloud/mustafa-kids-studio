import sys
sys.path.insert(0,'src')
from mks.core import load_db, character_report

def test_manifest():
    db=load_db(); assert db['project']['name']=='Mustafa Kids Studio'; assert 'mustafa' in db['characters']

def test_cast_refs():
    r=character_report(['mustafa','sara','ahmed'])
    assert r['ok'] is True
