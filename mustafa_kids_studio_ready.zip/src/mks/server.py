from __future__ import annotations
from typing import Any
from mcp.server import MCPServer
from .core import load_db, character_report
from .pipeline import run_episode

mcp=MCPServer("Mustafa Kids Studio", instructions=(
    "Autonomous controller for Mustafa Kids Studio. Before any generation, load the project manifest and enforce the immutable character contract. "
    "Never redesign official characters. Always use their official references and fixed voice IDs. Do not publish automatically. "
    "If required references or voice IDs are missing, report the exact blocker. Do not invent credentials or provider results."
))

@mcp.tool(title="Project manifest")
def project_manifest()->dict[str,Any]: return load_db()

@mcp.tool(title="List official cast")
def list_cast()->list[dict[str,str]]:
    return [{"id":k,"name_ar":v["name_ar"],"type":v["type"]} for k,v in load_db()["characters"].items()]

@mcp.tool(title="Character profile")
def character_profile(character_id:str)->dict[str,Any]:
    c=load_db()["characters"].get(character_id)
    if not c: raise ValueError(f"Unknown character: {character_id}")
    return {"id":character_id,**c}

@mcp.tool(title="Check production readiness")
def check_readiness(character_ids:list[str]|None=None)->dict[str,Any]:
    ids=character_ids or list(load_db()["characters"].keys())
    return character_report(ids)

@mcp.tool(title="Create episode")
async def create_episode(idea:str,duration_minutes:int=5,character_ids:list[str]|None=None)->dict[str,Any]:
    """Start the autonomous episode pipeline. In dry-run it creates a safe execution manifest without spending provider credits."""
    if duration_minutes<1 or duration_minutes>30: raise ValueError("duration_minutes must be 1..30")
    return await run_episode(idea,duration_minutes,character_ids)

def main(): mcp.run(transport="streamable-http", stateless_http=True, json_response=True)
if __name__=="__main__": main()
