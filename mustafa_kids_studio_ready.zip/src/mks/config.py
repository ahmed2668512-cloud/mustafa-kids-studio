from __future__ import annotations
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]
load_dotenv(ROOT / ".env")
DATA = ROOT / "data" / "characters.json"
OUTPUT = ROOT / os.getenv("OUTPUT_DIR", "outputs")
OUTPUT.mkdir(parents=True, exist_ok=True)

DRY_RUN = os.getenv("MKS_DRY_RUN", "true").lower() == "true"
MAX_COST = float(os.getenv("MKS_MAX_EPISODE_COST_USD", "0"))
AUTO_APPROVE_FREE = os.getenv("MKS_AUTO_APPROVE_FREE", "true").lower() == "true"
