from __future__ import annotations
import json, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from .config import DATA, OUTPUT, DRY_RUN, MAX_COST

def now(): return datetime.now(timezone.utc).isoformat()

def load_db() -> dict[str, Any]: return json.loads(DATA.read_text(encoding="utf-8"))

def save_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def new_job(idea: str, duration: int) -> dict[str, Any]:
    jid = f"ep_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    job = {"job_id":jid,"created_at":now(),"idea":idea,"duration_minutes":duration,"status":"created","dry_run":DRY_RUN,"budget_usd":MAX_COST}
    save_json(OUTPUT / jid / "job.json", job)
    return job

def character_report(ids: list[str]) -> dict[str, Any]:
    db=load_db(); out=[]; ok=True
    for cid in ids:
        c=db["characters"].get(cid)
        if not c: out.append({"id":cid,"exists":False}); ok=False; continue
        refs=[str((DATA.parent.parent / p).resolve()) for p in c.get("reference_images",[])]
        refs_ok=all(Path(p).exists() for p in refs)
        voice_ok=bool(c.get("voice",{}).get("voice_id"))
        out.append({"id":cid,"exists":True,"references":refs,"references_ok":refs_ok,"voice_configured":voice_ok})
        ok = ok and refs_ok
    return {"ok":ok,"characters":out}
