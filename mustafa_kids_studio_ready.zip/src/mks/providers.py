from __future__ import annotations
import os, httpx
from pathlib import Path
from typing import Any
from .config import DRY_RUN

class ProviderError(RuntimeError): pass

class ElevenLabs:
    def __init__(self): self.key=os.getenv("ELEVENLABS_API_KEY")
    async def tts(self, text:str, voice_id:str, out:Path)->dict[str,Any]:
        if DRY_RUN: return {"status":"dry_run","provider":"elevenlabs","voice_id":voice_id,"text":text}
        if not self.key: raise ProviderError("ELEVENLABS_API_KEY is missing")
        url=f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
        headers={"xi-api-key":self.key,"Content-Type":"application/json","Accept":"audio/mpeg"}
        payload={"text":text,"model_id":"eleven_multilingual_v2"}
        async with httpx.AsyncClient(timeout=120) as c:
            r=await c.post(url,headers=headers,json=payload); r.raise_for_status(); out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(r.content)
        return {"status":"ok","provider":"elevenlabs","path":str(out)}

class VideoProvider:
    async def generate(self, prompt:str, reference_paths:list[str], out:Path)->dict[str,Any]:
        base=os.getenv("VIDEO_API_BASE_URL"); key=os.getenv("VIDEO_API_KEY"); path=os.getenv("VIDEO_GENERATE_PATH","/v1/generate")
        if DRY_RUN: return {"status":"dry_run","provider":"video","prompt":prompt,"references":reference_paths}
        if not base or not key: raise ProviderError("VIDEO_API_BASE_URL/VIDEO_API_KEY are missing")
        # Provider-neutral contract: adapt this method to the chosen vendor's exact API.
        async with httpx.AsyncClient(timeout=180) as c:
            r=await c.post(base.rstrip("/")+path,headers={"Authorization":f"Bearer {key}"},json={"prompt":prompt,"references":reference_paths}); r.raise_for_status(); data=r.json()
        return {"status":"submitted","provider":"video","response":data}
