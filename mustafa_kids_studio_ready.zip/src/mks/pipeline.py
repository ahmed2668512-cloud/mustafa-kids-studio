from __future__ import annotations
from pathlib import Path
from typing import Any
from .core import load_db,new_job,save_json,character_report
from .config import OUTPUT
from .providers import ElevenLabs, VideoProvider, ProviderError

async def run_episode(idea:str,duration:int=5,characters:list[str]|None=None)->dict[str,Any]:
    db=load_db(); chars=characters or list(db["characters"].keys())[:3]
    report=character_report(chars)
    if not report["ok"]: return {"status":"blocked","reason":"Character references missing","report":report}
    job=new_job(idea,duration); root=OUTPUT/job["job_id"]
    manifest={"job":job,"characters":chars,"steps":[],"status":"running"}
    manifest["steps"].append({"name":"character_lock","status":"ok","report":report})
    # Claude remains the creative planner; this controller enforces the immutable character contract.
    scene_prompt=f"Create a child-safe 3D animated episode in Arabic Iraqi dialect. Idea: {idea}. Preserve official character identities exactly."
    video=VideoProvider()
    try:
        vr=await video.generate(scene_prompt, sum([db["characters"][c]["reference_images"] for c in chars],[]), root/"video_request.json")
        manifest["steps"].append({"name":"video","status":vr.get("status"),"result":vr})
        # Audio is only generated when a real voice id exists; dry-run remains safe.
        el=ElevenLabs()
        for cid in chars:
            vid=db["characters"][cid]["voice"].get("voice_id")
            if vid:
                ar=await el.tts("مرحبا!",vid,root/f"audio_{cid}.mp3")
                manifest["steps"].append({"name":f"voice:{cid}","status":ar.get("status"),"result":ar})
            else:
                manifest["steps"].append({"name":f"voice:{cid}","status":"pending_voice_id"})
    except ProviderError as e:
        manifest["status"]="blocked"; manifest["error"]=str(e); save_json(root/"manifest.json",manifest); return manifest
    manifest["status"]="ready_for_render" if any(s["name"]=="video" and s["status"]=="dry_run" for s in manifest["steps"]) else "submitted"
    save_json(root/"manifest.json",manifest); return manifest
