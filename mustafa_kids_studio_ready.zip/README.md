# Mustafa Kids Studio v1.0

Autonomous children's animation controller designed around a single Remote MCP connector for Claude.

## Goal
The intended UX is: **"Claude, create the new episode."** Claude uses this MCP controller as the production authority. The controller loads the immutable Character Bible, checks references, and then invokes configured media providers.

## Architecture
Claude → Remote MCP → Character/Voice Policy → Video Provider → ElevenLabs → Renderer/Storage.

The server is deliberately provider-neutral for video because video vendors expose different APIs. Set the chosen provider in `.env` and adapt only `src/mks/providers.py` to its exact API contract. ElevenLabs can also be connected directly to Claude through its hosted MCP connector.

## Character consistency
`data/characters.json` is the source of truth. Official reference images live in `data/references/`. The controller blocks production when required reference assets are missing. Voice IDs are never invented.

## Safe default
`MKS_DRY_RUN=true` by default. This lets you test the orchestration without spending credits. Set it to `false` only after configuring and testing provider credentials.

## Run locally
```bash
python -m venv .venv
# activate it
pip install .
cp .env.example .env
python -m mks.server
```
The MCP endpoint is normally `http://localhost:8000/mcp`.

## Deploy for Claude
Claude custom connectors use a Remote MCP URL reachable from Anthropic's cloud. Put this server behind HTTPS, add authentication, then add the public `/mcp` URL in Claude → Customize → Connectors → Add custom connector.

## Important production controls
- Keep publishing disabled until a separate publishing tool is intentionally added.
- Use a cost ceiling and explicit approval for paid generation.
- Do not store API keys in Git or the character database.
- Add OAuth 2.1 or another strong bearer-token verifier before exposing the server publicly.
- Adapt provider contracts to the exact vendor API; never fake a successful generation result.

## Current tools
- `project_manifest`
- `list_cast`
- `character_profile`
- `check_readiness`
- `create_episode`

## Verification
Run:
```bash
pytest -q
```
